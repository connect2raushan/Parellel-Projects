package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.AccountDao;
import com.cg.entities.Account;
import com.cg.entities.Customer;
@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	@Autowired
private	AccountDao accountDao;

	@Override
	public Account createAccount(Account account,Customer customer) {
		
		return accountDao.createAccount(account,customer);
	}

	@Override
	public Account showBalance(int accountNo) {
		// TODO Auto-generated method stub
		return accountDao.showBalance(accountNo);
	}

	@Override
	public Account deposite(int accountNo, int amount) {
		// TODO Auto-generated method stub
		return accountDao.deposite(accountNo, amount);
	}

	@Override
	public Account withDraw(int accountNo, int amount) {
		// TODO Auto-generated method stub
		return accountDao.withDraw(accountNo, amount);
	}

	@Override
	public Account fundTransfer(int accountNo, int accountNo1, int amount) {
		// TODO Auto-generated method stub
		return accountDao.fundTransfer(accountNo, accountNo1, amount);
	}

}

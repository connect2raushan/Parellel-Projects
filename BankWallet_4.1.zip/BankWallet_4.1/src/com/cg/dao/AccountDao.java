package com.cg.dao;

import com.cg.entities.Account;
import com.cg.entities.Customer;

public interface AccountDao {
	public Account createAccount(Account account,Customer customer);
	public Account showBalance(int accountNo);
	public Account deposite(int accountNo, int amount);
	public Account withDraw(int accountNo, int amount);
	public Account fundTransfer(int accountNo,int accountNo1, int amount);

}

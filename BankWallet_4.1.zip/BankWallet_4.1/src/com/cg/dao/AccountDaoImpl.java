package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entities.Account;
import com.cg.entities.Customer;
@Repository
public class AccountDaoImpl implements AccountDao {
	Account account= new Account();
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Account createAccount(Account account,Customer customer) {
		entityManager.persist(account);
		entityManager.persist(customer);
		//entityManager.flush();
		return account;
	}

	@Override
	public Account showBalance(int accountNo) {
		if(entityManager.find(Account.class, accountNo)!=null)
		{
			account=entityManager.find(Account.class, accountNo);
			System.out.println(account.getBalance());
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		
		return account;
	}

	@Override
	public Account deposite(int accountNo, int amount) {
		
		if(entityManager.find(Account.class, accountNo)!=null)
		{
			account=entityManager.find(Account.class, accountNo);
			amount=account.getBalance()+amount;
			account.setBalance(amount);
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		
		return account;
	}

	@Override
	public Account withDraw(int accountNo, int amount) {
		
		if(entityManager.find(Account.class, accountNo)!=null)
		{
			account=entityManager.find(Account.class, accountNo);
			if(account.getBalance()>amount)
			{
				amount=account.getBalance()-amount;
				account.setBalance(amount);
				System.out.println("Updated Amount: "+account.getBalance());
			}
			else
			{
				System.out.println("You don't have sufficient balance.\nBalance: "+account.getBalance());
			}
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		
		
		return account;
	}

	@Override
	public Account fundTransfer(int accountNo, int accountNo1, int amount) {
		
		if(entityManager.find(Account.class, accountNo)!=null && entityManager.find(Account.class, accountNo1)!=null )
		{
			
			account=entityManager.find(Account.class, accountNo);
			
			if(account.getBalance()>amount)
			{
				int amount1=account.getBalance()-amount;
				account.setBalance(amount1);
				
				account=entityManager.find(Account.class, accountNo1);
				amount1=account.getBalance()+amount;
				account.setBalance(amount1);
				System.out.println("Trasaction successfull!!");
				
			}
			else
			{
				System.out.println("You don't have sufficient balance.\nBalance: "+account.getBalance());
			}
		}
		else {
			System.out.println("User not exist");
		}
		
		
		
		return account;
	
	}

}

package com.cg.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Account;
import com.cg.entities.Customer;
import com.cg.service.AccountService;

@RestController
public class AccountController {
	Account account= new Account();
	Customer customer= new Customer();
	@Autowired
	private AccountService accountService;
	@RequestMapping(value="/create/{name}/{amount}/{contact}/{type}/{aadharNo}/{panNo}", method = RequestMethod.POST,headers="Accept=application/json")
	public String createAccount(@PathVariable String name,@PathVariable int amount,@PathVariable String contact,@PathVariable String type,@PathVariable String aadharNo,@PathVariable String panNo )
	{
		
		Random rand = new Random();
		int acNo = rand.nextInt(900000000) + 1000000000;
		account.setAccountNo(acNo);
		account.setName(name);
		account.setBalance(amount);
		account.setContactNo(contact);
		account.setAccountType(type);
		
		customer.setAccountNo(acNo);
		customer.setName(name);
		customer.setContact(contact);
		customer.setPanNo(panNo);
		customer.setAadharNo(aadharNo);
		
		account=accountService.createAccount(account,customer);
		String res="Added Successfully and Trainee Id is: "+account.getAccountNo();
		return res;
		
	}
	@RequestMapping(value="/show/{accountNo}", method = RequestMethod.GET,headers="Accept=application/json")
	public String showBalance(@PathVariable int accountNo)
	{
		 account= accountService.showBalance(accountNo);
		String res="Balance is: "+account.getBalance();
		return res;
		
	}
	@RequestMapping(value="/deposite/{accountNo}/{amount}", method = RequestMethod.PUT,headers="Accept=application/json")
	public Account deposite(@PathVariable("accountNo") int accountNo, @PathVariable("amount") int amount)
	{
		
		
		return accountService.deposite(accountNo, amount);
		
	}
	@RequestMapping(value="/withdraw/{accountNo}/{amount}", method = RequestMethod.PUT,headers="Accept=application/json")
	public Account withDraw(@PathVariable("accountNo") int accountNo, @PathVariable("amount")int amount)
	{
		return accountService.withDraw(accountNo, amount);
		
	}
	@RequestMapping(value="/transfer/{accountNo}/{accountNo1}/{amount}", method = RequestMethod.PUT,headers="Accept=application/json")
	public Account fundTransfer(@PathVariable("accountNo") int accountNo,@PathVariable("accountNo1") int accountNo1, @PathVariable("amount")int amount)
	{
		return accountService.fundTransfer(accountNo, accountNo1, amount);
		
	}

	

}

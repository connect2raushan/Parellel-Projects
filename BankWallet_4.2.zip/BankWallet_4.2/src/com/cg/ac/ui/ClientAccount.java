package com.cg.ac.ui;

import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;
import com.cg.ac.entity.Account;
import com.cg.ac.entity.Customer;
import com.cg.ac.service.AccountService;
import com.cg.ac.service.AccountServiceImpl;

public class ClientAccount {
	static AccountService accService=null;
	static Account account= null;
	static Customer customer=null;
	static Scanner scan = null;
	static int choice;
	public static void main(String[] args) {
		accService=new AccountServiceImpl();
		account= new Account();
		
		/*
		 * account=accService.showAccountList(); System.out.println(account);
		 */

		System.out.println("Welcome to wallet service\n");

		do {
			System.out.println("Enter your choice:");
			System.out.println("1. CREATE ACCOUNT");
			System.out.println("2. SHOW BALANCE");
			System.out.println("3. DEPOSITE");
			System.out.println("4. WITHDRAW");
			System.out.println("5. TRANSFER MONEY");
			System.out.println("6. PRINT TRANSACTION");
			System.out.println("7. EXIT");
			scan = new Scanner(System.in);
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				createAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
				
				//deposite(accountNo,amount);
				break;
			case 4:
				//withDraw(accountNo,amount);
				break;
			case 5:
				//fundTransfer(accountNo,accountNo1,amount);
				break;
			case 6:
				//printTransaction();
				break;
			case 7:
				System.out.println("Thank you for banking with us.");
				System.exit(0);
				break;

			default:
				break;
			}
		} while (choice != 7);
	}
	
	public static void createAccount() {

		System.out.println("Enter Your name:");
		String name = scan.next();
		try {
			if (accService.validateName(name)) {

				System.out.println("Enter initial balance:");
				double amount = scan.nextDouble();
				try {
					if (true) {
						System.out.println("Enter contact no:");
						String contact = scan.next();

						try {
							if (accService.validateContact(contact)) {
								System.out.println("Enter account type(saving or current)");
								String acType = scan.next();

								try {
									if (accService.validateAccouuntType(acType)) {
										Random rand = new Random();
										int acNo = rand.nextInt(900000000) + 1000000000;
										System.out.println("Enter PAN No: ");
										String panNo= scan.next();
										System.out.println("Enter Adhar No: ");
										String aadharNo= scan.next();
										try {
											if (accService.validateAadhar(aadharNo)) {
										Account account = new Account(acNo,amount, contact, acType);
										Customer customer= new Customer(acNo, name, panNo, aadharNo, acType, amount, LocalDate.now());
										accService.createAccount(account,customer);
										
											}
										} catch (Exception e) {
									
										} 
								}
								}catch (Exception e) {

								}

							}

						} catch (Exception e) {

						}
					}

				}

				catch (Exception e) {

				}
			}
		} catch (Exception e) {

		}
	}

	
	
	private static void showBalance() {
		System.out.println("Enter Account no:");
		int accountNo= scan.nextInt();
		account=accService.showAccountList();
		if(account.getAccountNo()==accountNo)
		{
		System.out.println(account.getBalance());
		}
		else{
			System.out.println("Account no doesn't exist");
		}
	}
	
	

}

package com.cg.ac.dao;

import com.cg.ac.entity.Account;
import com.cg.ac.entity.Customer;

public interface AccountDao {
	public Account showAccountList();
	public void createAccount(Account account, Customer customer);
	
	

}

package com.cg.ac.dao;

import java.time.LocalDate;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.ac.entity.Account;
import com.cg.ac.entity.Customer;

public class AccountDaoImpl implements AccountDao {

	@Override
	public void createAccount(Account account, Customer customer) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public Account showAccountList() {
		Resource res= new ClassPathResource("account.xml");
		BeanFactory factory= new XmlBeanFactory(res);
		Account account= (Account) factory.getBean("account");
		Customer customer= (Customer) factory.getBean("customer");
		
		customer.setAccountType(account.getAccountType());
		customer.setAccountNo(account.getAccountNo());
		customer.setBalance(account.getBalance());
		customer.setDate(LocalDate.now());
		System.out.println(customer);
		return account;

}

	
}

package com.cg.ac.exception;

public class AccountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}

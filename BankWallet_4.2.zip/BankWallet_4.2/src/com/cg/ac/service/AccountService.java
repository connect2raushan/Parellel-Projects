package com.cg.ac.service;

import com.cg.ac.entity.Account;
import com.cg.ac.entity.Customer;
import com.cg.ac.exception.AccountException;

public interface AccountService {
	public Account showAccountList();

	public void createAccount(Account account, Customer customer);
	
	public boolean validateName(String name) throws AccountException;
	public boolean validateAadhar(String aadharNo)throws AccountException;
	public boolean validateAccouuntType(String acType) throws AccountException;
	public boolean validateContact(String contact) throws AccountException;

}

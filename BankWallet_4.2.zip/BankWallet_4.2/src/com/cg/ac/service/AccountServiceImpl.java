package com.cg.ac.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ac.dao.AccountDao;
import com.cg.ac.dao.AccountDaoImpl;
import com.cg.ac.entity.Account;
import com.cg.ac.entity.Customer;
import com.cg.ac.exception.AccountException;

public class AccountServiceImpl implements AccountService {
AccountDao accountDao= new AccountDaoImpl();



@Override
public void createAccount(Account account, Customer customer) {
	// TODO Auto-generated method stub
	accountDao.createAccount(account, customer);
}


	@Override
	public Account showAccountList() {
		
		return accountDao.showAccountList();
	}
	
	
	public boolean validateName(String name) throws AccountException {
		Pattern p=Pattern.compile("[a-zA-Z]{2,12}");
		 Matcher m=p.matcher(name);
		 if(m.matches()) {
			 return true;
		 }
		 System.out.println("Enter name only");
		return false;
	}
	/*public boolean validateBalance(Double amount) throws AccountException {
		String temp=Double.toString(amount);
		if(Pattern.matches("[0-9]{1,9}", temp))
		{
			 return true;
		 }
		return false;
	}*/
	public boolean validateContact(String contact) throws AccountException {
		if(Pattern.matches("[789]{1}[0-9]{9}", contact))
		{
			 return true;
		 }
		System.out.println("10 digit no only");
		return false;
	}
	public boolean validateAccouuntType(String acType) throws AccountException {
		if(acType.equals("saving") || acType.equals("current"))
		{
			 return true;
		 }
		System.out.println("Enter saving or current only");
		return false;
	}

	public boolean validateAadhar(String aadharNo)throws AccountException {
		if(Pattern.matches("[0-9]{16}", aadharNo))
		{
			 return true;
		 }
		System.out.println("Enter 16 digit Aadhar No");
		return false;
	}


	

}

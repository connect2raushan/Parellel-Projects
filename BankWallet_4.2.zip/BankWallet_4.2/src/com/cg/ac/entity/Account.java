package com.cg.ac.entity;

public class Account {

}

package com.cg.ac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;

public class AccountDaoImp implements AccountDao {
	static Account account=null;
	static Connection con=null;
	
	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123" );
			con.setAutoCommit(false);
			System.out.println("Connected");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public String createAccount(Account account) throws AccountException {
		try {
		
		String sql="INSERT INTO AccountDetails VALUES(?,?,?,?,?)";
		PreparedStatement pstmt= con.prepareStatement(sql);
		pstmt.setString(1, account.getAccountNo());
		pstmt.setString(2, account.getName());
		pstmt.setDouble(3, account.getBalance());
		pstmt.setString(4, account.getContactNo());
		pstmt.setString(5, account.getAccountType());
		int updareRow=pstmt.executeUpdate();
		System.out.println(updareRow+" row inserted");
		con.commit();
		con.close();
		
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws AccountException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws AccountException {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.cg.ac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;

public class AccountDaoImp implements AccountDao {
	static Account account=null;
	static Connection con=null;
	static PreparedStatement pstmt= null;
	static ResultSet result=null;
	static String sql,sql1;
	
	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123" );
			con.setAutoCommit(false);
			System.out.println("Connected");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public String createAccount(Account account) throws AccountException {
		try {
		
		sql="INSERT INTO AccountDetails VALUES(?,?,?,?,?)";
		pstmt= con.prepareStatement(sql);
		
		pstmt.setString(1, account.getAccountNo());
		pstmt.setString(2, account.getName());
		pstmt.setDouble(3, account.getBalance());
		pstmt.setString(4, account.getContactNo());
		pstmt.setString(5, account.getAccountType());
		int updareRow=pstmt.executeUpdate();
		System.out.println(updareRow+" row inserted");
		con.commit();
		
		
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		
		try {
			sql="SELECT *FROM ACCOUNTDETAILS WHERE ACCOUNTNUMBER =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setString(1, accountNo); 
			result=pstmt.executeQuery();
			
			while (result.next()) {
				System.out.println(result.getDouble(3));
				
			}
			con.commit();
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws AccountException {
		
		try {
			sql=" UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE + ?) WHERE ACCOUNTNUMBER =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setDouble(1, amount); 
			pstmt.setString(2, accountNo); 
			pstmt.executeQuery();
			con.commit();
			
		} catch (Exception e) {
			
		}
		return null;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {

		try {
			sql=" UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE - ?) WHERE ACCOUNTNUMBER =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setDouble(1, amount); 
			pstmt.setString(2, accountNo); 
			pstmt.executeQuery();
			con.commit();
			
		} catch (Exception e) {
			
		}
		return null;
		
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws AccountException {
		try {
		sql=" UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE - ?) WHERE ACCOUNTNUMBER =?";
		sql1="UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE + ?) WHERE ACCOUNTNUMBER =?";
		pstmt= con.prepareStatement(sql);
		pstmt.setDouble(1, amount); 
		pstmt.setString(2, accountNo); 
		pstmt.executeQuery();
		pstmt= con.prepareStatement(sql1);
		pstmt.setDouble(1, amount); 
		pstmt.setString(2, accountNo1); 
		pstmt.executeQuery();
		con.commit();
		
		} catch (Exception e) {
			
		}
		return null;
	}

}

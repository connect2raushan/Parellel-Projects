package com.cg.ac.ui;

import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;
import com.cg.ac.service.AccountServiceImpl;

public class AccountMain {
	static AccountServiceImpl acservice = null;
	static Scanner scan = null;
	static int choice;
	static Account ac=null;
	static int accountNo,accountNo1;
	static double amount;

	public static void main(String[] args) {
		acservice = new AccountServiceImpl();
		System.out.println("Welcome to wallet service\n");

		do {
			System.out.println("Enter your choice:");
			System.out.println("1. CREATE ACCOUNT");
			System.out.println("2. SHOW BALANCE");
			System.out.println("3. DEPOSITE");
			System.out.println("4. WITHDRAW");
			System.out.println("5. TRANSFER MONEY");
			System.out.println("6. PRINT TRANSACTION");
			System.out.println("7. EXIT");
			scan = new Scanner(System.in);
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				createAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
				
				deposite(accountNo,amount);
				break;
			case 4:
				withDraw(accountNo,amount);
				break;
			case 5:
				fundTransfer(accountNo,accountNo1,amount);
				break;
			case 6:
				printTransaction();
				break;
			case 7:
				System.out.println("Thank you for banking with us.");
				System.exit(0);
				break;

			default:
				break;
			}
		} while (choice != 7);
	}

	public static void createAccount() {

		System.out.println("Enter Your name:");
		String name = scan.next();
		try {
			if (acservice.validateName(name)) {

				System.out.println("Enter initial balance:");
				double amount = scan.nextDouble();
				try {
					if (true) {
						System.out.println("Enter contact no:");
						String contact = scan.next();

						try {
							if (acservice.validateContact(contact)) {
								System.out.println("Enter account type(saving or current)");
								String acType = scan.next();

								try {
									if (acservice.validateAccouuntType(acType)) {
										Random rand = new Random();
										int acNo = rand.nextInt(900000000) + 1000000000;
										System.out.println("Enter PAN No: ");
										String panNo= scan.next();
										System.out.println("Enter Adhar No: ");
										String aadharNo= scan.next();
										try {
											if (acservice.validateAadhar(aadharNo)) {
										Account account = new Account(acNo,amount, contact, acType);
										Customer customer= new Customer(acNo, name, panNo, aadharNo, acType, amount, LocalDate.now());
										acservice.createAccount(account,customer);
										System.out.println("Account No:"+account.getAccountNo()+ " created succesfully.");
											}
										} catch (Exception e) {
									
										} 
								}
								}catch (Exception e) {

								}

							}

						} catch (Exception e) {

						}
					}

				}

				catch (Exception e) {

				}
			}
		} catch (Exception e) {

		}

	}
	public static void showBalance()
	{
		
		System.out.println("Enter 10 digit account no:");
		int accountNo=scan.nextInt();
		try {
			ac=acservice.showBalance(accountNo);
			System.out.println("Your account balance is: "+ac.getBalance());
			
		} catch (Exception e) {
			
		}
		
		
	}
	
	public static void deposite(int accountNo, double amount)
	{
		try {
		System.out.println("Enter account no:");
		accountNo=scan.nextInt();
		System.out.println("Enter amount to deposite:");
		amount=scan.nextDouble();
		ac=acservice.deposite(accountNo, amount);
		amount=amount+ac.getBalance();
		ac.setBalance(amount);	
		System.out.println("Updated balance:"+ac.getBalance());
		} catch (AccountException e) {
			
			e.printStackTrace();
		}
		
	}
	public static void withDraw(int accountNo, double amount)
	{
		try {
			System.out.println("Enter account no:");
			accountNo=scan.nextInt();
			System.out.println("Enter amount to withdraw:");
			amount=scan.nextDouble();
			ac=acservice.withDraw(accountNo, amount);
			if(ac.getBalance()<amount)
			{
				System.out.println("Not sufficient balance:");
			}
			else {
			amount=ac.getBalance()-amount;
			ac.setBalance(amount);	
			System.out.println("Updated balance:"+ac.getBalance());
			}
			} catch (AccountException e) {
				
				e.printStackTrace();
			}
	}
	
	public static void fundTransfer(int accountNo,int accountNo1, double amount)
	{
		try {
		System.out.println("Enter sender account no:");
		accountNo=scan.nextInt();
		System.out.println("Enter receiver account no:");
		accountNo1=scan.nextInt();
		System.out.println("Enter amount to send:");
		amount= scan.nextDouble();
		ac=acservice.fundTransfer(accountNo,accountNo1,amount);
		System.out.println("Transaction successful.\nYour updated balance is: "+ac.getBalance());
		
		} catch (AccountException e) {
			
			e.printStackTrace();
		}
		
		
		
	}
	public static void printTransaction()
	{
		try {
			acservice.printTransaction();
		} catch (AccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

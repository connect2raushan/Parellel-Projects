package com.cg.ac.bean;
public class Account {
	private int accountNo;
	private double balance;
	private String contactNo;
	private String accountType;
	public Account(int accountNo, double balance, String contactNo, String accountType) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.contactNo = contactNo;
		this.accountType = accountType;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "\nAccount [accountNo=" + accountNo + ", balance=" + balance + ", contactNo=" + contactNo
				+ ", accountType=" + accountType + "]";
	}
	
	
	
	
	

}

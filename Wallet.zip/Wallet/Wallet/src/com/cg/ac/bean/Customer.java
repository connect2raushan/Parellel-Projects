package com.cg.ac.bean;

import java.time.LocalDate;

public class Customer {
	private int accountNo;
	private String name;
	private String panNo;
	private String aadharNo;
	private String accountType;
	private double balance;
	private LocalDate date;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Customer(int accountNo, String name, String panNo, String aadharNo, String accountType, double balance,
			LocalDate date) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.panNo = panNo;
		this.aadharNo = aadharNo;
		this.accountType = accountType;
		this.balance = balance;
		this.date = date;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "\nCustomer [accountNo=" + accountNo + ", name=" + name + ", panNo=" + panNo + ", aadharNo=" + aadharNo
				+ ", accountType=" + accountType + ", balance=" + balance + ", date=" + date + "]";
	}
	
	

}

package com.cg.ac.dao;

import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;
import com.cg.ac.util.CollectionUtil;

public class AccountDaoImpl implements AccountDao {
	

	@Override
	public String createAccount(Account account,Customer customer) throws AccountException {
		CollectionUtil.createAccount(account,customer);
		return account.getContactNo();
	}

	@Override
	public Account showBalance(int accountNo) throws AccountException {
		Account account= CollectionUtil.showBalance(accountNo);
		return account;
	}

	@Override
	public Account deposite(int accountNo, double amount) throws AccountException {
		Account account= CollectionUtil.deposite(accountNo,amount);
		return account;

	}

	@Override
	public Account withDraw(int accountNo, double amount) throws AccountException {
		Account account= CollectionUtil.withDraw(accountNo,amount);
		return account;

	}

	@Override
	public Account fundTransfer(int accountNo,int accountNo1, double amount) throws AccountException {
		Account account=CollectionUtil.fundTransfer(accountNo,accountNo1,amount);
		return account;

	}

	@Override
	public void printTransaction() throws AccountException {
		CollectionUtil.printTransaction();

	}

}

package com.cg.ac.dao;


import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;


public interface AccountDao {
	public String createAccount(Account account,Customer customer)throws AccountException;
	public Account showBalance(int accountNo)throws AccountException;
	public Account deposite(int accountNo, double amount)throws AccountException;
	public Account withDraw(int accountNo, double amount)throws AccountException;
	public Account fundTransfer(int accountNo,int accountNo1, double amount) throws AccountException;
	public void printTransaction()throws AccountException;
	
	

}

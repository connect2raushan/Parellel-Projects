package com.cg.ac.util;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Random;

import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;

public class CollectionUtil {
	 static Random rand = new Random();
	static Account account=null;
	static Account account1=null;
	static int randomAc;
	static HashMap<Integer, Account> hashAcc=null;
	static HashMap<Integer, Customer> hashCus=null;
	static 
	{
		hashAcc= new HashMap<Integer, Account>();
		hashAcc.put(1322565263, new Account(1322565263, 20000, "7415417237", "saving"));
		hashAcc.put(1322565264, new Account(1322565264, 45000, "7415417238", "Saving"));
		hashAcc.put(1322565265, new Account(1322565265, 25000, "7415417239", "Current"));
		
	}
	static
	{
		hashCus=new HashMap<Integer, Customer>();
		hashCus.put(1322565263, new Customer(1322565263, "Raushan", "CEVPM452R", "236589658458612365", "saving", 20000, LocalDate.of(2019, 03, 21)));
		hashCus.put(1322565264, new Customer(1322565264, "Krishna", "CEVPM452K", "236589658458612365", "saving", 45000, LocalDate.of(2019, 03, 22)));
		hashCus.put(1322565265, new Customer(1322565265, "Chetan", "CEVPM452C", "236589658458612365", "saving", 25000, LocalDate.of(2019, 03, 23)));
	}

	public static void createAccount(Account account, Customer customer) {
		
		
		hashAcc.put(account.getAccountNo(), account);
		hashCus.put(customer.getAccountNo(), customer);
		
	}

	public static Account showBalance(int accountNo) {
		return account= hashAcc.get(accountNo);
		
	}

	public static Account deposite(int accountNo, double amount) {
		
		account= hashAcc.get(accountNo);
		
		return account=hashAcc.get(accountNo);
	}

	public static Account withDraw(int accountNo, double amount) {
		account= hashAcc.get(accountNo);
		return account=hashAcc.get(accountNo);
	}

	public static Account fundTransfer(int accountNo,int accountNo1, double amount) {
		account= hashAcc.get(accountNo);
		account1= hashAcc.get(accountNo1);
		
		double amount1=account.getBalance()-amount;
		account.setBalance(amount1);
		double amount2=account.getBalance()+amount;
		account.setBalance(amount2);
		return account1=hashAcc.get(accountNo);
		
	}
	public static void printTransaction()
	{
		System.out.println(hashAcc.values());
		System.out.println(hashCus.values());
	}

}

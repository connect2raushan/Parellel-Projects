package com.cg.ac.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.ac.bean.Account;
import com.cg.ac.dao.AccountDao;
import com.cg.ac.dao.AccountDaoImpl;
import com.cg.ac.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	AccountDao acdao= new AccountDaoImpl();

	@Override
	public String createAccount(Account account) throws AccountException {
		acdao.createAccount(account);
		return account.getContactNo();
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		Account account=acdao.showBalance(accountNo);
		return account;
	}

	@Override
	public Account deposite(String accountNo, double amount)throws AccountException {
		Account account=acdao.deposite(accountNo,amount);
		return account;
		
		
		

	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {
		
		Account account=acdao.withDraw(accountNo,amount);
		return account;

	}

	@Override
	public Account fundTransfer(String accountNo,String accountNo1, double amount) throws AccountException {
		Account account=acdao.fundTransfer(accountNo,accountNo1,amount);
		return account;

	}

	@Override
	public void printTransaction() throws AccountException {
		// TODO Auto-generated method stub

	}
	public boolean validateName(String name) throws AccountException {
		Pattern p=Pattern.compile("[a-zA-Z]{2,12}");
		 Matcher m=p.matcher(name);
		 if(m.matches()) {
			 return true;
		 }
		return false;
	}
	/*public boolean validateBalance(Double amount) throws AccountException {
		String temp=Double.toString(amount);
		if(Pattern.matches("[0-9]{1,9}", temp))
		{
			 return true;
		 }
		return false;
	}*/
	public boolean validateContact(String contact) throws AccountException {
		if(Pattern.matches("[789]{1}[0-9]{9}", contact))
		{
			 return true;
		 }
		return false;
	}
	public boolean validateAccouuntType(String acType) throws AccountException {
		if(acType.equals("saving") || acType.equals("current"))
		{
			 return true;
		 }
		return false;
	}

}

package com.cg.ac.dao;

import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;
import com.cg.ac.util.CollectionUtil;

public class AccountDaoImpl implements AccountDao {
	

	@Override
	public String createAccount(Account account) throws AccountException {
		CollectionUtil.createAccount(account);
		return account.getContactNo();
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		Account account= CollectionUtil.showBalance(accountNo);
		return account;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws AccountException {
		Account account= CollectionUtil.deposite(accountNo,amount);
		return account;

	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {
		Account account= CollectionUtil.withDraw(accountNo,amount);
		return account;

	}

	@Override
	public Account fundTransfer(String accountNo,String accountNo1, double amount) throws AccountException {
		Account account=CollectionUtil.fundTransfer(accountNo,accountNo1,amount);
		return account;

	}

	@Override
	public void printTransaction() throws AccountException {
		// TODO Auto-generated method stub

	}

}

package com.cg.ac.dao;

import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;

public class AccountDaoImp implements AccountDao {
	static Account account=null;
	
	
	
	@Override
	public String createAccount(Account account) throws AccountException {
		
		return null;
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		
		
		return null;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws AccountException {
		
		return null;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {

		
		return null;
		
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws AccountException {
		
		return null;
	}

}

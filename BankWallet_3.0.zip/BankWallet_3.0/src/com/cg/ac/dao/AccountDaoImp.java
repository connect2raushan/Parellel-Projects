package com.cg.ac.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;

public class AccountDaoImp implements AccountDao {
	Account account= new Account();
	Account account1= new Account();
	static EntityManagerFactory factory =null;
	static EntityManager em=null;
	static{
		factory = Persistence.createEntityManagerFactory("JPA-PU");
		em = factory.createEntityManager();
		em.getTransaction().begin();
	}
	
	

	
	
	@Override
	public String createAccount(Account account,Customer customer) throws AccountException {
	this.account=account;
		em.persist(account);
		em.persist(customer);
		em.getTransaction().commit();
		em.close();
		factory.close();
		return null;
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		
		account=em.find(Account.class, accountNo);
		return account;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws AccountException {
		
		account=em.find(Account.class, accountNo);
		amount=amount+account.getBalance();
		account.setBalance(amount);
		em.getTransaction().commit();
		return null;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {

		account=em.find(Account.class, accountNo);
		if(account.getBalance()>amount)
		{
			amount=account.getBalance()-amount;
			account.setBalance(amount);
			System.out.println("Updated Amount: "+account.getBalance());
		}
		else
		{System.out.println("You don't have sufficient balance.\nBalance: "+account.getBalance());}
		
		em.getTransaction().commit();
		return null;
		
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws AccountException {
		account=em.find(Account.class, accountNo);
		account1=em.find(Account.class, accountNo1);
		if(account.getBalance()>amount)
		{
			double amount1=account.getBalance()-amount;
			account.setBalance(amount1);
			double amount2=account.getBalance()+amount;
			account.setBalance(amount2);
			System.out.println(" Sender Updated Amount: "+account.getBalance());
			
		}
		else
		{System.out.println("You don't have sufficient balance.\nBalance: "+account.getBalance());}
		em.getTransaction().commit();
		return null;
	}
	/*em.close();
	factory.close();*/

}

package com.cg2;

import java.util.ArrayList;

public class CurrencyListImpl implements CurrencyList {
private ArrayList<String> currList;

	public ArrayList<String> getCurrList() {
	return currList;
}

public void setCurrList(ArrayList<String> currList) {
	this.currList = currList;
}

	@Override
	public ArrayList<String> getCurrencyList() {
		// TODO Auto-generated method stub
		return currList;
	}

}

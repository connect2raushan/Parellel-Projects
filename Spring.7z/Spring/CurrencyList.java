package com.cg2;

import java.util.ArrayList;

public interface CurrencyList {
	public ArrayList<String> getCurrencyList();

}

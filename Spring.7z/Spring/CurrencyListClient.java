package com.cg2;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class CurrencyListClient {

	public static void main(String[] args) {
		
		Resource res= new ClassPathResource("CurrencyConverter.xml");
		BeanFactory factory= new XmlBeanFactory(res);
		CurrencyList curr= (CurrencyList) factory.getBean("currrencyList");
		List curs= curr.getCurrencyList();
		System.out.println(curs);
		

	}

}

package com.cg.ac.dao;

import java.util.List;

import com.cg.ac.entity.Account;

public interface AccountDao {
	public abstract Account save(Account account);
	public abstract List<Account> loadAll();

}

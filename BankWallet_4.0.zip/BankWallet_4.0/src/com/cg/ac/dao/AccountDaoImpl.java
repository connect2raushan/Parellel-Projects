package com.cg.ac.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.ac.entity.Account;

@Repository
public class AccountDaoImpl implements AccountDao {
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Account save(Account account) {
		entityManager.persist(account);
		entityManager.flush();
		return account;
		
	}

	@Override
	public List<Account> loadAll() {
		TypedQuery<Account> querry=entityManager.createQuery("select a from Account a",Account.class);
		return querry.getResultList();
	}

}

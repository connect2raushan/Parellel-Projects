package com.cg.ac.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Account implements Serializable{
	@Id
	@Column(name = "Account_No",length = 12)
	private String accountNo;
	@Column(name = "Name",length = 20)
	private String name;
	@Column(name = "Balance",length = 20)
	private double balance;
	@Column(name = "Contact",length = 10)
	private String contactNo;
	@Column(name = "Account",length = 20)
	private String accountType;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String accountNo,String name, double balance, String contactNo, String accountType) {
		super();
		this.name = name;
		this.balance = balance;
		this.contactNo = contactNo;
		this.accountType = accountType;
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	

}

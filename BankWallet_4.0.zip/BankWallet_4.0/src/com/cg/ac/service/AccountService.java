package com.cg.ac.service;

import java.util.List;

import com.cg.ac.entity.Account;



public interface AccountService {
	public abstract Account save(Account account);
	public abstract List<Account> loadAll();
}

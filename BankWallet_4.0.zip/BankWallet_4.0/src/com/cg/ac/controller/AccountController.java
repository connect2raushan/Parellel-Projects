package com.cg.ac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.ac.entity.Account;
import com.cg.ac.service.AccountService;



@Controller
public class AccountController {
	@Autowired
	private AccountService accountService;
	@RequestMapping("/index")
	public String getHomePage(Model model)
	{
		model.addAttribute("empList", accountService.loadAll());
		model.addAttribute("accountType",new String[]
				{"Current","Savings","Other"}
				);
		model.addAttribute("account", new Account());
		return "index";
	}
@RequestMapping(value="/save",method=RequestMethod.POST)
	
	public String saveEmployee(@ModelAttribute("account") Account account,Model model)
	{
		account =  accountService.save(account);
	
		model.addAttribute("message","Employee with Id"+account.getAccountNo()+"added Successfully");
		return "redirect:/index.html";
	}
	

}
